# aoc2025

[![Package Version](https://img.shields.io/hexpm/v/aoc2025)](https://hex.pm/packages/aoc2025)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/aoc2025/)

```sh
gleam add aoc2025@1
```
```gleam
import aoc2025

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/aoc2025>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```
